fx_version 'cerulean'
game 'gta5'

description 'Seatbelt and Cruise Control System'
author 'chillsiderp'
version '1.0.0'

shared_script 'config.lua'

client_scripts {
    'client/seatbelt.lua',
    'client/cruise.lua'
}
ui_page 'html/index.html'

files {
    'html/index.html',
    'html/seatbelt.ogg'
}

dependencies {
    'es_extended',
    'okokNotify'
}
