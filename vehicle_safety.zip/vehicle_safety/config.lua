Config = {}

-- Pásy
Config.SeatbeltKey = 29 -- B
Config.EjectSpeed = 90.0 -- km/h

-- Tempomat
Config.CruiseKeys = {
    137, -- CapsLock
}
Config.SeatbeltWarningSpeed = 30 -- km/h

