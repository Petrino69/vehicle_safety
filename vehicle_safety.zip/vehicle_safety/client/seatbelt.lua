local seatbeltOn = false
local showBeltWarning = false
local warningActive = false

CreateThread(function()
    while true do
        Wait(0)

        -- Aktivace a deaktivace pásu pouze ve vozidle
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            if IsControlJustPressed(0, Config.SeatbeltKey) then
                seatbeltOn = not seatbeltOn
                local message = seatbeltOn and "Pásy zapnuty" or "Pásy vypnuty"
                local type = seatbeltOn and "success" or "warning"
                TriggerEvent('okokNotify:Alert', "Pásy", message, 3000, type)
            end
        end

        -- Pokud jsi v autě a nemáš pásy, můžeš být vymrštěn při nárazu
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            local speed = GetEntitySpeed(veh) * 3.6

            -- Eject při kolizi bez pásu
            if not seatbeltOn and speed > Config.EjectSpeed and HasEntityCollidedWithAnything(veh) then
                local coords = GetEntityCoords(ped)
                TaskLeaveVehicle(ped, veh, 4160)
                Wait(100)
                SetEntityCoords(ped, coords.x, coords.y, coords.z - 1.0, true, true, true, false)
                SetEntityVelocity(ped, GetEntityVelocity(veh))
                TriggerEvent('okokNotify:Alert', "Pásy", "Byl jsi vymrštěn z vozidla!", 4000, 'error')

                -- Aktivace Ragdoll efektu po vymrštění a poškození
                SetPedToRagdoll(ped, 5000, 5000, 1, false, false, false)  -- Ragdoll efekt
                ApplyDamageToPed(ped, 10, true)  -- Poškození hráče (10 HP), můžeš změnit hodnotu dle potřeby
            end
        end
    end
end)

-- Zvuk varování
function playSeatbeltWarningSound()
    SendNUIMessage({ type = 'playSeatbeltWarning' })
end

function stopSeatbeltWarningSound()
    SendNUIMessage({ type = 'stopSeatbeltWarning' })
end

-- Varování při jízdě bez pásu
CreateThread(function()
    while true do
        Wait(500)
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            local speed = GetEntitySpeed(veh) * 3.6

            if speed > Config.SeatbeltWarningSpeed and not seatbeltOn then
                showBeltWarning = true
                if not warningActive then
                    warningActive = true
                    playSeatbeltWarningSound()
                end
            else
                showBeltWarning = false
                if warningActive then
                    warningActive = false
                    stopSeatbeltWarningSound()
                end
            end
        else
            if warningActive then
                warningActive = false
                stopSeatbeltWarningSound()
            end
            showBeltWarning = false
        end
    end
end)

-- Ikona varování
CreateThread(function()
    while true do
        Wait(0)
        if showBeltWarning then
            SetTextFont(4)
            SetTextProportional(1)
            SetTextScale(0.7, 0.7)
            SetTextColour(255, 0, 0, 200)
            SetTextEdge(1, 0, 0, 0, 255)
            SetTextCentre(true)
            SetTextEntry("STRING")
            AddTextComponentString("⚠️ NEMÁŠ PÁSY!")
            DrawText(0.92, 0.5)
        end
    end
end)
