local cruiseEnabled = false
local cruiseSpeed = 0

-- Aktivace tempomatu
RegisterCommand("cruisecontrol", function()
    local veh = GetVehiclePedIsIn(PlayerPedId(), false)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == PlayerPedId() then
        local currentSpeed = GetEntitySpeed(veh) * 3.6 -- přepočet na km/h
        if not cruiseEnabled then
            if currentSpeed >= 30.0 then
                cruiseSpeed = GetEntitySpeed(veh)
                cruiseEnabled = true
                TriggerEvent('okokNotify:Alert', "TEMPOMAT", "Tempomat aktivován", 3000, 'success')
            else
                TriggerEvent('okokNotify:Alert', "TEMPOMAT", "Musíš jet alespoň 30 km/h pro aktivaci tempomatu", 3000, 'info')
            end
        else
            cruiseEnabled = false
            TriggerEvent('okokNotify:Alert', "TEMPOMAT", "Tempomat deaktivován", 3000, 'error')
        end
    end
end)

-- Klávesa pro aktivaci (např. Caps Lock)
RegisterKeyMapping('cruisecontrol', 'Přepnout tempomat', 'keyboard', 'CAPITAL')

-- Tempomat smyčka
CreateThread(function()
    while true do
        Wait(0)
        if cruiseEnabled then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)

            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                local currentSpeed = GetEntitySpeed(veh)

                -- Vypnutí tempomatu při zásahu hráče
                if IsControlPressed(0, 71) or IsControlPressed(0, 72) then
                    cruiseEnabled = false
                    TriggerEvent('okokNotify:Alert', "TEMPOMAT", "Tempomat deaktivován řízením", 3000, 'error')
                else
                    -- Udržování rychlosti tempomatu
                    if currentSpeed < cruiseSpeed - 0.5 then
                        -- Zpomalování, pokud je rychlost nižší než tempomat
                        SetVehicleForwardSpeed(veh, cruiseSpeed)
                    elseif currentSpeed > cruiseSpeed + 1.0 then
                        -- Plynule zpomalíme, aby vozidlo nedojíždělo příliš rychle
                        SetVehicleForwardSpeed(veh, cruiseSpeed)
                    end
                    -- Řízení je volné, neblokujeme A/D pro zatáčení
                end
            else
                cruiseEnabled = false
            end
        end
    end
end)
